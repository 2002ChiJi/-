#pragma once
#include "HardFile.h"
void html(vector<string>& files);
void Css();
void Scripts();