#pragma once

#include "direct.h"  
#include <string>  
#include "stdio.h"  
#include "stdlib.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#include <ctype.h>
#include <io.h>
#include <vector>        
#include <iomanip>    
#include <ctime>  

using namespace std;