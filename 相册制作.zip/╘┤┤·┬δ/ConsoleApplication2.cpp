#include "HardFile.h"
#include "WriteFile.h"

void GetFiles(string path, vector<string>& files);
void OtherThing();

string path;
vector<string> files;

int main()
{
	system("color f0");
	system("title ��������С���");
	//md&WriteSomeFile
	{
		system("md css");
		system("md scripts");
		system("md images\\slides");
		Css();
		Scripts();
	}
	//Rename MoveFile 
	GetFiles("pictures", files);   //GetFileName
	{
		string filename;
		int charnum;

		for (int num = 0; num < files.size(); num++)
		{
			stringstream box;
			box << num;
			box >> filename;

			for(charnum=files[num].size();files[num][charnum]!='.';charnum--){}
			for (; charnum <= files[num].size(); charnum++)
				filename = filename + files[num][charnum];

			rename(string("D:\\OldTime\\"+ files[num]).c_str(), string("D:\\OldTime\\images\\slides\\"+filename).c_str());

			filename.clear();
			charnum = 0;
		}
	}
	//WriteHtml
	{
		files.clear();
		GetFiles("images\\slides", files);
		html(files);
	}
	OtherThing();
}

void GetFiles(string path, vector<string>& files)
{
	long   hFile = 0;
	struct _finddata_t fileinfo;
	string p;
	if ((hFile = _findfirst(p.assign(path).append("\\*").c_str(), &fileinfo)) != -1)
	{

		do {
			if ((fileinfo.attrib   &   _A_SUBDIR))
			{
				if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
					GetFiles(p.assign(path).append("\\").append(fileinfo.name), files);
			}
			else
			{
				files.push_back(p.assign(path).append("\\").append(fileinfo.name));
			}
		} while (_findnext(hFile, &fileinfo) == 0);
		_findclose(hFile);
	}
}

void OtherThing()
{
	rename(string("D:\\OldTime\\Button.png").c_str(), string("images\\camera_skins.png").c_str());
	//HideFile
	system("attrib +s +h D:\\OldTime\\images\\camera_skins.png");
	system("attrib +s +h D:\\OldTime\\scripts");
	system("attrib +s +h D:\\OldTime\\images");
	system("attrib +s +h D:\\OldTime\\Music");
	system("attrib +s +h D:\\OldTime\\css");
	system("attrib +r D:\\OldTime\\���.html");
	//Delete
	system("rd Pictures");
}