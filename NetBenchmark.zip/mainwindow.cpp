﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint);
}

void MainWindow::mousePressEvent(QMouseEvent* e)
{
    if (e->button() == Qt::LeftButton)
        last = e->globalPos();
}

void MainWindow::mouseMoveEvent(QMouseEvent* e)
{
    if (e->buttons() == Qt::LeftButton)
    {
        int dx = e->globalX() - last.x();
        int dy = e->globalY() - last.y();
        last = e->globalPos();
        move(x() + dx, y() + dy);
    }
}
//鼠标按下

void MainWindow::mouseReleaseEvent(QMouseEvent* e)
{
    if (e->button() == Qt::LeftButton)
    {
        int dx = e->globalX() - last.x();
        int dy = e->globalY() - last.y();
        move(x() + dx, y() + dy);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

QString MainWindow::GetDelay(QString Src)
{
    QStringList Buffer=Src.split("=");
    return Buffer.last();
}

QString MainWindow::GetShake(QString Src)
{
    QStringList Buffer=Src.split("=");
    int delay[3]={Buffer[1].toInt(),Buffer[3].toInt(),Buffer[5].toInt()};

    return ((delay[1]-delay[2])>(delay[2]-delay[0]))?
            QString::number(delay[1]-delay[2]):QString::number(delay[2]-delay[0]);
}

QString MainWindow::GetLost(QString Src)
{
    QStringList Buffer=Src.split("(");
    return Buffer[1];
}

void MainWindow::on_pushButton_clicked()
{
    QMessageBox::warning(this,
                         tr("按OK继续"), tr("程序会在一段时间内无响应，请耐心等待"),
                         QMessageBox::Ok, QMessageBox::Ok);

    QProcess p(nullptr);
    p.start("cmd", QStringList()<<"/c"<<"ping www.baidu.com -n 10");
    p.waitForStarted();
    p.waitForFinished();
    QString strTemp=QString::fromLocal8Bit(p.readAllStandardOutput());  //获得输出

    QStringList StrS=strTemp.split("\r\n");
    QString result[2]={StrS[14],StrS[16]};
    result[0].replace("%","(");
    result[1].replace("，","=");
    result[1].replace("ms","");
    result[1].replace(" ","");

    ui->Delay->setText(GetDelay(result[1]));
    ui->Shake->setText(GetShake(result[1]));
    ui->Lost->setText(GetLost(result[0]));

    QMessageBox::warning(this,tr("          "), tr("测试完成"),
                         QMessageBox::Ok, QMessageBox::Ok);
}
