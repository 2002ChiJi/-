﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMouseEvent>
#include <QProcess>
#include <QMessageBox>
#include <QStringList>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

private slots:
    void mouseMoveEvent(QMouseEvent* e)    override;
    void mousePressEvent(QMouseEvent* e)   override;
    void mouseReleaseEvent(QMouseEvent* e) override;

    void on_pushButton_clicked();

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private:
    QPoint last;
    Ui::MainWindow *ui;

    QString GetDelay(QString Src);
    QString GetShake(QString Src);
    QString GetLost(QString Src);
};

#endif // MAINWINDOW_H
