﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ImgProcesser.h"

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    setWindowFlags(Qt::CustomizeWindowHint | Qt::WindowMinimizeButtonHint);

    camera = new QCamera(this);
    viewfind = new QCameraViewfinder();

    viewfind->show();
    camera->setViewfinder(viewfind);
    cameraImageCapture = new QCameraImageCapture(camera);

    cameraImageCapture->setCaptureDestination(QCameraImageCapture::CaptureToFile);
    camera->setCaptureMode(QCamera::CaptureStillImage);
    connect(cameraImageCapture, &QCameraImageCapture::imageCaptured, this, &MainWindow::displayImage);

    camera->start();
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Capture_clicked()
{
    cameraImageCapture->capture();
}

void MainWindow::displayImage(int id, QImage image)
{
    ui->displayLabel->setPixmap(QPixmap::fromImage(image));

    ImageProcesser.EmptyImgs();
    ImageProcesser.GiveImg(ui->displayLabel);
}

void MainWindow::on_Save_clicked()
{
    QString FileName = QUuid::createUuid().toString();
    FileName.append(".jpg");

    const QPixmap* pixmap = ui->displayLabel->pixmap();
    if (pixmap)pixmap->save(FileName);
}

void MainWindow::on_horizontalSlider_sliderMoved(int position)
{
    ui->Level->setText(QString::number(position));
}


void MainWindow::on_Close_clicked()
{
    camera->stop();
    viewfind->close();
    this->close();
}

void MainWindow::on_Mode_currentIndexChanged(const QString& arg1)
{
    ImageProcesser.GiveImg(ui->displayLabel);

    if (arg1 == QString::fromLocal8Bit("变成黑白"))ImageProcesser.ToGrey();
    else if(arg1==QString::fromLocal8Bit("二值化"))ImageProcesser.Binarization();
    else ImageProcesser.RollBack();

    ImageProcesser.ShowImg(ui->displayLabel);
}


void MainWindow::on_horizontalSlider_sliderReleased()
{
    ImageProcesser.GiveImg(ui->displayLabel);

    if (ui->Mode->currentText() == QString::fromLocal8Bit("调节亮度"))
        ImageProcesser.Bright(ui->horizontalSlider->value());
    else if(ui->Mode->currentText() == QString::fromLocal8Bit("对比度"))
        ImageProcesser.Contrast(float(ui->horizontalSlider->value()) /100);
    else if(ui->Mode->currentText() == QString::fromLocal8Bit("饱和度"))
        ImageProcesser.Saturation(float(ui->horizontalSlider->value()));
    else if(ui->Mode->currentText() == QString::fromLocal8Bit("亮度平均"))
        ImageProcesser.AVGBrightness(ui->horizontalSlider->value());
    else if(ui->Mode->currentText() == QString::fromLocal8Bit("高斯模糊"))
        ImageProcesser.Blur(ui->horizontalSlider->value());
    else if(ui->Mode->currentText() == QString::fromLocal8Bit("暖色调"))
        ImageProcesser.Colorize(float(ui->horizontalSlider->value())/100);
    else
        ImageProcesser.RollBack();

    ui->horizontalSlider->setValue(0);
    on_horizontalSlider_sliderMoved(0);
    ImageProcesser.ShowImg(ui->displayLabel);
}


void MainWindow::on_Undo_clicked()
{
    ImageProcesser.RollBack();
    ImageProcesser.ShowImg(ui->displayLabel);
}
