﻿#ifndef IMGPROCESSER_H
#include <mainwindow.h>

template <typename CallBackTy>
void ImgaeForEach(QImage* Img,CallBackTy CallBack)
{
    int XMax = Img->width(), YMax = Img->height();
    for (int x = 0; x < XMax; x++)
        for (int y = 0; y < YMax; y++)
            Img->setPixelColor(x,y,CallBack(Img->pixel(x, y)));
}

class
{
private:
    QStack<QImage> Imgs;

    inline void CheckVal(int* Val)
    {
        if (*Val>255) *Val=255;
        else if( *Val<0) *Val=0;
    }
    QImage applyEffectToImage(QImage src, QGraphicsEffect *effect)
    {
        QGraphicsScene scene;
        QGraphicsPixmapItem item;
        item.setPixmap(QPixmap::fromImage(src));
        item.setGraphicsEffect(effect);
        scene.addItem(&item);
        QImage res(src.size(), QImage::Format_ARGB32);
        QPainter ptr(&res);
        scene.render(&ptr, QRectF(), QRectF(0,0, src.width(), src.height() ) );
        return res;
    }/*https://stackoverflow.com/questions/14915129/qimage-transform-using-qgraphicsblureffect,有修改*/
public:
    inline void RollBack()
    {
        if(!Imgs.empty())
            Imgs.pop();
    }
    inline void EmptyImgs(){Imgs.clear();}
    inline void GiveImg(QLabel* Container){Imgs.push_back(Container->pixmap()->toImage());}
    inline void ShowImg(QLabel* Container){Container->setPixmap(QPixmap::fromImage(*(Imgs.end() - 1)));}

    void ToGrey()
    {
        short RGB;
        QColor NewColor;

        auto CallBack=[&](QRgb rgb)->QColor&{
            RGB =
                    qRed(rgb) * 3 +
                    qGreen(rgb) * 6 +
                    qBlue(rgb);
            RGB /= 10;

            NewColor.setRgb(RGB, RGB, RGB);
            return NewColor;
        };
        ImgaeForEach<decltype (CallBack)>(Imgs.end() - 1,CallBack);
    }
    void Binarization()
    {
        short Color;
        QColor NewColor;

        auto CallBack=[&](QRgb rgb)->QColor&{
            if(qRed(rgb)>128)Color=255;
            else Color=0;

            NewColor.setRgb(Color,Color,Color);
            return NewColor;
        };
        ImgaeForEach<decltype (CallBack)>(Imgs.end() - 1,CallBack);
    }
    void Blur(int strength)
    {
        RollBack();

        QGraphicsBlurEffect* effect=new QGraphicsBlurEffect;
        effect->setBlurRadius(strength);
        QImage img=applyEffectToImage(*(Imgs.end()-1),effect);

        Imgs.push(img);
    }
    void Bright(int Luminance)
    {
        int HSV[3];
        QColor NewColor;

        auto CallBack=[&](QRgb rgb)->QColor&{
            NewColor=rgb;
            NewColor.getHsv(HSV,HSV+1,HSV+2);
            HSV[2]+=Luminance;

            CheckVal(HSV+2);
            NewColor.setHsv(HSV[0],HSV[1],HSV[2]);
            return NewColor;
        };
        ImgaeForEach<decltype (CallBack)>(Imgs.end() - 1,CallBack);
    }
    void Contrast(float strength)
    {
        int RGB[3];
        QColor NewColor;

        auto CallBack=[&](QRgb rgb)->QColor&{
            RGB[0]=(qRed(rgb)+(qRed(rgb)-128)*strength);
            RGB[1]=(qGreen(rgb)+(qGreen(rgb)-128)*strength);
            RGB[2]=(qBlue(rgb)+(qBlue(rgb)-128)*strength);

            CheckVal(RGB),CheckVal(RGB+1),CheckVal(RGB+2);
            NewColor.setRgb(RGB[0],RGB[1],RGB[2]);
            return NewColor;
        };
        ImgaeForEach<decltype (CallBack)>(Imgs.end() - 1,CallBack);
    }
    void Saturation(int strength)
    {
        int HSV[3];
        QColor NewColor;

        auto CallBack=[&](QRgb rgb)->QColor&{
            NewColor=rgb;
            NewColor.getHsv(HSV,HSV+1,HSV+2);
            HSV[1]+=strength;

            CheckVal(HSV+1);
            NewColor.setHsv(HSV[0],HSV[1],HSV[2]);
            return NewColor;
        };
        ImgaeForEach<decltype (CallBack)>(Imgs.end() - 1,CallBack);
    }
    void AVGBrightness(int factor)
    {
        int HSV[3];
        QColor NewColor;

        if(factor>0)factor=10-factor+1;
        else if(factor<0)factor=-(10+factor)-1;
        else return;

        auto CallBack=[&](QRgb rgb)->QColor&{
            NewColor=rgb;
            NewColor.getHsv(HSV,HSV+1,HSV+2);
            HSV[2]-=(HSV[2]-128)/factor;

            CheckVal(HSV+2);
            NewColor.setHsv(HSV[0],HSV[1],HSV[2]);
            return NewColor;
        };
        ImgaeForEach<decltype (CallBack)>((Imgs.end() - 1),CallBack);
    }
    void Colorize(float strength)
    {
        RollBack();

        QGraphicsColorizeEffect *effect=new QGraphicsColorizeEffect;
        if(strength>0)effect->setColor(QColor(236,138,0));
        else effect->setColor(QColor(0,34,205));
        effect->setStrength(abs(strength));

        QImage img=applyEffectToImage(*(Imgs.end()-1),effect);
        Imgs.push(img);
    }
}static ImageProcesser;
#define IMGPROCESSER_H

#endif // IMGPROCESSER_H
