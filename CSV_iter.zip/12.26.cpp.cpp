﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*=========================
请仔细阅读以下注释，它可以帮助您使用本函数
球球你，真的要仔细阅读哦
===========================*/

/*
该函数可用于解析任意CSV文件（一行的数据不得多于5个）
用法：
首先必须知道待读取的CSV文件，每一行的数据类型是什么，比如:
1,2.5,Hello World
这一行有三个数据，类型分别是int,double和char*
然后调用Create_GetDataFromFile这个宏，并按照顺序填入数据类型，比如：
在本例(1,2.5,Hello World)中，数据类型分别是int,double,char*
另外，数据类型不得大于5个（但可以等于），不足5个的用void补足,数据类型中不得有指针，
所以，最终结果为：
Create_GetDataFromFile(int,double,char,void,void)
创建好后，我们可以使用Call_GetDataFromFile函数来解析CSV文件：
该函数会返回一个bool值，当返回值为假时表示已经读到文件尾，为真时表示可以继续读取
Call_GetDataFromFile需要填入类型，表示要把CSV文件解析成什么类型的数据，具体要求和Create_GetDataFromFile所填入的类型一样
然后我们需要传入一个文件指针，表示解析哪个csv文件，还需要传递其它指针，表示要把解析出来的数据的存放地点。
指针类型必须和Create_GetDataFromFile所填入的类型一样，如果填入的是void类型，那么指针要填写NULL
*/

void charPtr2void(void* from, void* to) { void; }
void charPtr2int(void* from, void* to) { *(int*)to = atof((const char*)from); }
void charPtr2float(void* from, void* to) { *(float*)to = atof((const char*)from); }
void charPtr2double(void* from, void* to) { *(double*)to = atof((const char*)from); }
void charPtr2char(void* from, void* to) { memmove(to, from, strlen((const char*)from) + 1);}

#define Create_GetDataFromFile(ty1,ty2,ty3,ty4,ty5)\
bool GetDataFromeFile##ty1##ty2##ty3##ty4##ty5\
(FILE* fileptr,ty1* ptr1,ty2* ptr2,ty3* ptr3,ty4* ptr4,ty5* ptr5)\
{\
	static char buffer[512],*ptr;\
	if(fscanf(fileptr, "%[^\n]", buffer) == EOF)return false;\
	fgetc(fileptr);\
	ptr=strtok(buffer,",");charPtr2##ty1(ptr,ptr1);\
	ptr=strtok(NULL,",");if(ptr!=buffer)charPtr2##ty2(ptr,ptr2);\
	ptr=strtok(NULL,",");if(ptr!=buffer)charPtr2##ty3(ptr,ptr3);\
	ptr=strtok(NULL,",");if(ptr!=buffer)charPtr2##ty4(ptr,ptr4);\
	ptr=strtok(NULL,",");if(ptr!=buffer)charPtr2##ty5(ptr,ptr5);\
return true;\
}
#define Call_GetDataFromFile(ty1,ty2,ty3,ty4,ty5) GetDataFromeFile##ty1##ty2##ty3##ty4##ty5

/*
以下为示例代码
*/

Create_GetDataFromFile(int, double, void, void, void)  
//先创建一个可以解析数据类型为int,double,,,的csv文件的函数，数据类型小于或等于5个，不足5个的用void补齐
Create_GetDataFromFile(int, void, void, void, void)
//先创建一个可以解析数据类型为int,,,,的csv文件的函数，数据类型小于或等于5个，不足5个的用void补齐
int main()
{
	int id;
	double score;
	char movieName[1024], buffer[1024];
	FILE* averageScore = fopen("average_ratings.csv", "r");

	//然后调用该函数，首先填写好数据类型（不足5个的用void补齐），最后再传入参数（如果类型为void的话传入NULL）
	while (Call_GetDataFromFile(int, double, void, void, void)(averageScore, &id, &score, NULL, NULL, NULL))
		printf("%d,%lf\n", id, score);

	fclose(averageScore);  //重置文件指针
	averageScore = fopen("average_ratings.csv", "r");

	//然后调用该函数，首先填写好数据类型（不足5个的用void补齐），最后再传入参数（如果类型为void的话传入NULL）
	while (Call_GetDataFromFile(int, void, void, void, void)(averageScore, &id, NULL, NULL, NULL, NULL))
		printf("%d\n", id);
}