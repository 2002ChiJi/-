/*
VER: 1.0
���ļ��ṩ���������ɱ����飬�ַ������ļ�IO��printf��ʵ�ֻ��߰�װ
�ܹ��ڽ���C���Կ���ʱ�ṩ���ֵĹ��ߣ�����д���������ʱ�䣬�򻯿�������
���д��붼�������ԣ������������ߵ�ˮƽ��������BUG�����λС��ʹ��

���ļ��ṩ�˼��������ܣ�����λ�ڵ���ʱ������Ϊ��������ȷ����Ĵ���
���Ҫ�������붨�� _CPLUS_DEBUG_MODE_ �꣬���رգ�ɾ���ú꼴��

�������ߣ������� ��ʹ�øô���ʱ������GPL3.0Э�� ��л����ʹ��
                                                           21.7.11
*/

#define _CPLUS_DEBUG_MODE_

#pragma once
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>

typedef int bool;
#define TRUE 1
#define FALSE 0

/*
��������
*/
#define _ERROR_TITLE_ "�������󣡳��򼴽��ر�"
#define _ERROR_ARGV_(argv) "\n���� " #argv " ����ȷ,���ܳ����������Ĵ�С,Ϊ��������"
#define _ERROR_NULL_  "\n��������ĳ����ԱΪNULL"
#define _ERROR_LOCATION_(FunctionName) "λ�� " __FILE__ "\n�ĺ��� " FunctionName " �������⣺"

void SendErrorMessage(const char* error)
{
	MessageBoxA(NULL, error,_ERROR_TITLE_, MB_ICONERROR | MB_OK);
	abort();
}

/*
List
�漰��dataʱ�Ὣ����Ϊ����
*/

typedef struct ListNode
{
	struct ListNode* next;
	void* data;
}ListNode;

typedef struct ListData
{
	ListNode* head, * end;
	int length;
}ListData;

void ListInit(ListData* list)
{
	list->end = list->head = NULL;
	list->length = 0;
}

void ListDestory(void(*DestoryFunction)(void*), ListNode* node)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (node->next == NULL) 
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.Destory") _ERROR_NULL_);
#endif

	if (DestoryFunction == NULL)
	{
		for (ListNode* now; node != NULL;)
		{
			now = node;
			node = node->next;

			free(now->data);
			free(now);
		}
	}
	else
	{
		for (ListNode* now; node != NULL;)
		{
			now = node;
			node = node->next;

			DestoryFunction(now->data);
			free(now);
		}
	}
}

inline  ListNode* ListFindNode(const int position, ListData* list) //���ҵ�position��Ԫ��
{
#ifdef _CPLUS_DEBUG_MODE_
	if (list->head == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.FindNode") _ERROR_NULL_);
	if (list->length<=position||position<0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.FindNode") _ERROR_ARGV_(position));
#endif

	ListNode* pos = list->head;
	for (int num = 0; num < position; num++)
		pos = pos->next;
	return pos;
}

void ListNodeInsertA(const int position, void* data, ListData* list)  //���뵽positionǰ��
{
#ifdef _CPLUS_DEBUG_MODE_
	if (list->head == NULL || data == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.InsertA") _ERROR_NULL_);
	if (list->length <= position || position < 0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.InsertA") _ERROR_ARGV_(position));
#endif

	ListNode* node = (ListNode*)malloc(sizeof(ListNode));
	node->data = data;

	if (position == 0)
	{
		node->next = list->head;
		list->head = node;
	}
	else
	{
		ListNode* pos = ListFindNode(position - 1, list);
		node->next = pos->next;
		pos->next = node;
	}
	list->length += 1;
}

void ListNodeInsertB(const int position, void* data, ListData* list)  //���뵽position����
{
#ifdef _CPLUS_DEBUG_MODE_
	if (list->head == NULL || data == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.InsertB") _ERROR_NULL_);
	if (list->length <= position || position < 0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.InsertB") _ERROR_ARGV_(position));
#endif

	ListNode* pos = ListFindNode(position, list);
	ListNode* node = (ListNode*)malloc(sizeof(ListNode));

	node->data = data;
	node->next = pos->next;
	pos->next = node;

	if (position == list->length - 1)
		list->end = node;
	list->length += 1;
}

void ListNodeDelete(const int position, void(*DestoryFunction)(void*), ListData* list) //ɾ����position��Ԫ��
{
#ifdef _CPLUS_DEBUG_MODE_
	if (list->head == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.DeleteNode") _ERROR_NULL_);
	if (list->length <= position || position < 0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.DeleteNode") _ERROR_ARGV_(position));
#endif

	ListNode* Deleted;
	if (position == 0)
	{
		Deleted = list->head;
		list->head = list->head->next;
	}
	else
	{
		ListNode* pos = ListFindNode(position - 1, list);
		Deleted = pos->next;
		pos->next = Deleted->next;

		if (position == list->length - 1)
			list->end = pos;
	}

	if (DestoryFunction == NULL)
		free(Deleted->data);
	else
		DestoryFunction(Deleted->data);
	free(Deleted);

	list->length -= 1;
}

void ListDelete(const int from, const int to, void(*DestoryFunction)(void*), ListData* list) //ɾ��[from,to]�����ڵ�����
{
#ifdef _CPLUS_DEBUG_MODE_
	if (list->head == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.DeleteList") _ERROR_NULL_);
	if (to >= list->length || from > to || from < 0 || to < 0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.DeleteList") _ERROR_ARGV_("from ���� to"));
#endif

	ListNode* Deleted, * To = ListFindNode(to, list);
	if (from == 0)
	{
		Deleted = list->head;
		list->head = To->next;
	}
	else
	{
		ListNode* From = ListFindNode(from - 1, list);
		Deleted = From->next;
		From->next = To->next;

		if (to == list->length - 1)
			list->end = From;
	}

	To->next = NULL;
	ListDestory(DestoryFunction, Deleted);
	list->length -= (to - from + 1);
}

void ListPushBack(void* data, ListData* list)
{
	ListNode* NewNode = malloc(sizeof(ListNode));
	NewNode->data = data;
	NewNode->next = NULL;

	if (list->head == NULL)
		list->head = list->end = NewNode;
	else
	{
		list->end->next = NewNode;
		list->end = NewNode;
	}
	list->length++;
}

inline void ListForEach(void(*Op)(void*), ListData* list)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (Op == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionList.ForEach") _ERROR_NULL_);
#endif

	for (ListNode* now = list->head; now != NULL; now = now->next)
		Op(now->data);
}

struct
{
	void (*Init)(ListData* list);
	void (*Destory)(void(*DestoryFunction)(void*), ListNode* node);
	ListNode* (*FindNode)(const int position, ListData* list);
	void (*InsertA)(const int position, void* data, ListData* list);
	void (*InsertB)(const int position, void* data, ListData* list);
	void (*DeleteNode)(const int position, void(*DestoryFunction)(void*), ListData* list);
	void (*DeleteList)(const int from, const int to, void(*DestoryFunction)(void*), ListData* list);
	void (*PushBack)(void* data, ListData* list);
	void (*ForEach)(void(*Op)(void*), ListData* list);
}static const FunctionList =
{
&ListInit,&ListDestory,&ListFindNode,&ListNodeInsertA,
&ListNodeInsertB,&ListNodeDelete,&ListDelete,&ListPushBack,
&ListForEach
};

/*
Vector
��ʹ�õ�ʱ���������Լ�Ҫ�������ı�������
���ø���������ָ���ʱ����ش�������������Ȩ������
�漰������Elementʱ�������и��ƣ������Element��Ϊ����(ElementΪָ�����)
*/

typedef struct VectorData
{
	void(*DestoryFunction)(void*);
	unsigned char ElementSize;
	unsigned Length, used;
	void* VectorHead;
}VectorData;

void VectorInit(unsigned char ElenmentSize, void(*DestoryFunction)(void*), VectorData* vector)
{
	vector->DestoryFunction = DestoryFunction;
	vector->ElementSize = ElenmentSize;
	vector->VectorHead = malloc(0);
	vector->Length = 0;
	vector->used = 0;
}

void VectorResize(const unsigned newLength, VectorData* vector)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (vector->VectorHead == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.Resize") _ERROR_NULL_);
	if (newLength <= 0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.Resize") _ERROR_ARGV_(newLength));
#endif

	void* temp = realloc(vector->VectorHead, newLength * vector->ElementSize);

	vector->VectorHead = temp;
	vector->Length = newLength;
	vector->used =
		(vector->used > newLength ? newLength : vector->used);
}

void VectorPushBack(void* Element, VectorData* vector)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (Element==NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.PushBuck") _ERROR_NULL_);
#endif

	if (vector->used == vector->Length)
		VectorResize((vector->Length + 1) * 2, vector);

	void* pt = ((char*)vector->VectorHead) + (vector->used * vector->ElementSize);
	memmove(pt, Element, vector->ElementSize);

	vector->used++;
}

void VectorInsertA(const unsigned position, const void* Element, VectorData* vector)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (vector->VectorHead == NULL || Element == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.InsertA") _ERROR_NULL_);
	if (position < 0 || position >= vector->used)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.InsertA") _ERROR_ARGV_(position));
#endif

	if (vector->used == vector->Length)
		VectorResize((vector->Length) * 2, vector);

	int size = vector->ElementSize;
	char* head = (char*)vector->VectorHead;
	memmove((head + (position + 1) * size), (head + position * size), (vector->used - position) * size);
	memmove((head + position * size), Element, size);

	vector->used++;
}

void VectorInsertB(const unsigned position, const void* Element, VectorData* vector)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (vector->VectorHead == NULL || Element == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.InsertB") _ERROR_NULL_);
	if (position < 0 || position >= vector->used)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.InsertB") _ERROR_ARGV_(position));
#endif

	if (vector->used == vector->Length)
		VectorResize((vector->Length) * 2, vector);

	int size = vector->ElementSize;
	char* head = (char*)vector->VectorHead;
	memmove((head + (position + 2) * size), (head + (position + 1) * size), (vector->used - position) * size);
	memmove((head + (position + 1) * size), Element, size);

	vector->used++;
}

void VectorRemove(const unsigned position, VectorData* vector)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (vector->VectorHead == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.Remove") _ERROR_NULL_);
	if (position < 0 || position >= vector->used)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.Remove") _ERROR_ARGV_(position));
#endif

	int size = vector->ElementSize;
	char* head = (char*)vector->VectorHead;
	memmove((head + (position)*size), (head + (position + 1) * size), (vector->used - position + 1) * size);

	vector->used--;
}

void VectorDestory(VectorData* vector)
{
	if (vector->DestoryFunction == NULL)
		free(vector->VectorHead);
	else
		vector->DestoryFunction(vector->VectorHead);

	vector->VectorHead = NULL;
	vector->ElementSize = vector->Length = vector->used = 0;
}

inline void VectorEmpty(VectorData* vector)
{
	vector->used = 0;
}

inline const void* VectorAt(const unsigned position, VectorData* vector)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (vector->VectorHead == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.At") _ERROR_NULL_);
	if (position < 0 || position >= vector->used)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.At") _ERROR_ARGV_(position));
#endif

	return ((char*)vector->VectorHead) + (position * vector->ElementSize);
}

inline void VectorChange(const unsigned position, void* Element, VectorData* vector)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (vector->VectorHead == NULL || Element == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.Change") _ERROR_NULL_);
	if (position < 0 || position >= vector->used)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.Change") _ERROR_ARGV_(position));
#endif

	void* pt = ((char*)vector->VectorHead) + (position * vector->ElementSize);
	memmove(pt, Element, vector->ElementSize);
}

inline void VectorForEach(void(*Op)(void*), VectorData* vector)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (Op == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionVector.ForEach") _ERROR_NULL_);
#endif

	char* now = vector->VectorHead;
	for (int counter = 0; counter < vector->used; counter++, now += vector->ElementSize)
		Op(now);

}

struct
{
	void (*Init)(unsigned char ElenmentSize, void(*DestoryFunction)(void*), VectorData* vector);
	void (*Resize)(const unsigned newLength, VectorData* vector);
	void (*PushBack)(void* Element, VectorData* vector);
	void (*InsertA)(const unsigned position, const void* Element, VectorData* vector);
	void (*InsertB)(const unsigned position, const void* Element, VectorData* vector);
	void (*Remove)(const unsigned position, VectorData* vector);
	void (*Destory)(VectorData* vector);
	void (*Empty)(VectorData* vector);
	const void* (*At)(const unsigned position, VectorData* vector);
	void (*Change)(const unsigned position, void* Element, VectorData* vector);
	void (*ForEach)(void(*Op)(void*), VectorData* vector);
}static const FunctionVector =
{
	&VectorInit,&VectorResize,&VectorPushBack,&VectorInsertA,&VectorInsertB,
	&VectorRemove,&VectorDestory,&VectorEmpty,&VectorAt,&VectorChange,&VectorForEach
};

/*
CPString
�ײ����Vector
*/

typedef struct CPStrData
{
	VectorData data;
}CPStrData;

void CPStrInit(const char* str, CPStrData* CPStr)
{
	FunctionVector.Init(sizeof(char), NULL, &(CPStr->data));
	if (str == NULL)str = "";

	FunctionVector.Resize(strlen(str) + 1, &(CPStr->data));
	memmove(CPStr->data.VectorHead, str, strlen(str) + 1);
	CPStr->data.used = strlen(str) + 1;
}

inline void CPStrDestory(CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.Destory") _ERROR_NULL_);
#endif

	FunctionVector.Destory(&(CPStr->data));
}

inline void CPStrEmpty(CPStrData* CPStr)
{
	memset(CPStr->data.VectorHead, '\0', CPStr->data.used);
	FunctionVector.Empty(&(CPStr->data));
}

inline const char* CPStrAt(const unsigned position, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.At") _ERROR_NULL_);
	if (position < 0 || position >= CPStr->data.used)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.At") _ERROR_ARGV_(position));
#endif

	return FunctionVector.At(position, &(CPStr->data));
}

inline char* CPStrc_str(CPStrData* CPStr)
{
	return CPStr->data.VectorHead;
}

void CPStrCover(const unsigned position, const  char* str, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL||str==NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.Cover") _ERROR_NULL_);
	if (position < 0 || position >= CPStr->data.used)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.Cover") _ERROR_ARGV_(position));
#endif

	const unsigned  len = strlen(str);
	if (len > CPStr->data.used - position - 1)
	{
		FunctionVector.Resize((len + position + 1) * 2, &(CPStr->data));
		CPStr->data.used = len + position + 1;
		CPStrc_str(CPStr)[CPStr->data.used - 1] = '\0';
	}

	memmove((char*)(CPStr->data.VectorHead) + position, str, len);
}

void CPStrRemove(const unsigned from, const unsigned to, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.Remove") _ERROR_NULL_);
	if (to >= CPStr->data.used|| from > to || from < 0 || to<0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.Remove") _ERROR_ARGV_("from ���� to"));
#endif

	if (from == to)
		FunctionVector.Remove(from, &(CPStr->data));
	else
	{
		char* head = CPStrc_str(CPStr);
		memmove((head + from), (head + to + 1), CPStr->data.used - to - 1);
		CPStr->data.used -= (to - from + 1);
	}
}

void CPStrAppendStr(const char* str, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (str == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.AppendStr") _ERROR_NULL_);
#endif

	int len = strlen(str);

	if (len + CPStr->data.used > CPStr->data.Length)
		FunctionVector.Resize((len + CPStr->data.used) * 2, &(CPStr->data));

	memmove(CPStrc_str(CPStr) + CPStr->data.used - 1, str, len + 1);
	CPStr->data.used += len;
}

void CPStrAppendChar(const char str, CPStrData* CPStr)
{
	char* head = CPStrc_str(CPStr);

	if (CPStr->data.used + 1 > CPStr->data.Length)
		FunctionVector.Resize((CPStr->data.used + 1) * 2, &(CPStr->data));

	head[CPStr->data.used - 1] = str;
	head[CPStr->data.used] = '\0';
	CPStr->data.used += 1;
}

void CPStrInsertA(const unsigned position, const char* str, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL || str == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.InsertA") _ERROR_NULL_);
	if (CPStr->data.used <= position || position < 0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPstr.InsertA") _ERROR_ARGV_(position));
#endif

	int len = strlen(str);
	char* head = CPStrc_str(CPStr);

	if (len + CPStr->data.used > CPStr->data.Length)
		FunctionVector.Resize((len + CPStr->data.used) * 2, &(CPStr->data));

	memmove(head + position + len, head + position, CPStr->data.used - position);
	memmove(head + position, str, len);

	CPStr->data.used += len;
	head[CPStr->data.used - 1] = '\0';
}

void CPStrInsertB(const unsigned position, const char* str, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL || str == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.InsertB") _ERROR_NULL_);
	if (CPStr->data.used <= position || position < 0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPstr.InsertB") _ERROR_ARGV_(position));
#endif

	int len = strlen(str);
	char* head = CPStrc_str(CPStr);

	if (len + CPStr->data.used > CPStr->data.Length)
		FunctionVector.Resize((len + CPStr->data.used) * 2, &(CPStr->data));

	memmove(head + position + len + 1, head + position + 1, CPStr->data.used - position - 1);
	memmove(head + position + 1, str, len);

	CPStr->data.used += len;
	head[CPStr->data.used - 1] = '\0';
}

inline void CPStrShorten(const unsigned newLength, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.used <= newLength)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPstr.Shorten") _ERROR_ARGV_(newLength));
#endif

	CPStr->data.used = newLength + 1;
	*((char*)(CPStr->data.VectorHead) + (newLength)) = '\0';
}

inline void CPStrCpy(const char* str, CPStrData* CPStr)		//���ƺ�ԭCPStr���ַ����ᱻ���
{
#ifdef _CPLUS_DEBUG_MODE_
	if (str == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.StrCpy") _ERROR_NULL_);
#endif

	CPStrDestory(CPStr);
	CPStrInit(str, CPStr);
}

int CPStrFind(const unsigned start, const char* str, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL || str == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.StrFind") _ERROR_NULL_);
	if (CPStr->data.used <= start || start < 0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPstr.StrFind") _ERROR_ARGV_(start));
#endif

	char* head = CPStr->data.VectorHead;
	int pos = (strlen(str) == 1) ?
		strchr((head + start), str[0]) : strstr((head + start), str);

	if (pos == 0)return -1;
	else return (int)pos - (int)(CPStr->data.VectorHead);
}

inline unsigned CPStrCount(const char* str, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL || str == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.Count") _ERROR_NULL_);
#endif

	int start = 0, len = strlen(str), pos, count = 0;
	for (;; start = (pos + len), count++)
	{
		pos = CPStrFind(start, str, CPStr);
		if (pos == -1)break;
	}
	return count;
}

void CPStrTransform(CPStrData* CPStr, bool IsLower)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.Transform") _ERROR_NULL_);
#endif

	char* head = CPStr->data.VectorHead;

	if (IsLower)
	{
		for (; (*head) != '\0'; head++)
			if ((*head) >= 'A' && (*head) <= 'Z') (*head) += 32;
	}
	else
	{
		for (; (*head) != '\0'; head++)
			if ((*head) >= 'a' && (*head) <= 'z') (*head) -= 32;
	}
}

void CPStrRelpace(const char* from, const char* to, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL || from == NULL || to == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.Replace") _ERROR_NULL_);
#endif

	if (CPStrFind(0, from, CPStr) != -1)
	{
		CPStrData buffer;
		CPStrInit(NULL, &buffer);
		char* head = CPStrc_str(CPStr);

		for (unsigned num = 0; num < CPStr->data.used; num++)
		{
			if (!strncmp(head + num, from, strlen(from)))
			{
				CPStrAppendStr(to, &buffer);
				num += strlen(from) - 1;
			}
			else
				CPStrAppendChar(head[num], &buffer);
		}
		CPStrCpy(CPStrc_str(&buffer), CPStr);
		CPStrDestory(&buffer);
	}
}

inline int CPStrLen(CPStrData* CPStr)
{
	return CPStr->data.used - 1;
}

char* CPStrSplit(const unsigned from, const unsigned to, CPStrData* CPStr)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (CPStr->data.VectorHead == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.Split") _ERROR_NULL_);
	if (to >= CPStr->data.used || from > to || from < 0 || to < 0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionCPStr.Split") _ERROR_ARGV_("from ���� to"));
#endif

	char* ret = malloc(to - from + 2),
		* begin = (char*)(CPStr->data.VectorHead) + from;

	memmove(ret, begin, to - from + 1);
	ret[to - from + 1] = '\0';

	return ret;
}

struct
{
	void (*Init)(const char* str, CPStrData* CPStr);
	void (*Destory)(CPStrData* CPStr);
	void (*Empty)(CPStrData* CPStr);
	const char* (*At)(const unsigned position, CPStrData* CPStr);
	void (*Cover)(const unsigned position, const  char* str, CPStrData* CPStr);
	void (*Remove)(const unsigned from, const unsigned to, CPStrData* CPStr);
	void (*AppendStr)(const char* str, CPStrData* CPStr);
	void (*AppendChar)(const char* Element, CPStrData* CPStr);
	void (*InsertA)(const unsigned position, const char* str, CPStrData* CPStr);
	void (*InsertB)(const unsigned position, const char* str, CPStrData* CPStr);
	void (*Shorten)(const unsigned newLength, CPStrData* CPStr);
	void (*Cpy)(const char* str, CPStrData* CPStr);
	int (*StrFind)(const unsigned start, const char* str, CPStrData* CPStr);
	unsigned (*Count)(const char* str, CPStrData* CPStr);
	void (*Transform)(CPStrData* CPStr, bool IsLower);
	void (*Relpace)(const char* from, const char* to, CPStrData* CPStr);
	int (*StrLen)(CPStrData* CPStr);
	char* (*Split)(const unsigned from, const unsigned to, CPStrData* CPStr);
	char* (*c_str)(CPStrData* CPStr);
}static const FunctionCPStr =
{
&CPStrInit,&CPStrDestory,&CPStrEmpty,&CPStrAt,&CPStrCover,&CPStrRemove,
&CPStrAppendStr,&CPStrAppendChar,&CPStrInsertA,&CPStrInsertB,&CPStrShorten,&CPStrCpy,&CPStrFind,
&CPStrCount,&CPStrTransform,&CPStrRelpace,&CPStrLen,&CPStrSplit,&CPStrc_str
};

/*
FILE
�������߼��������ص��¶�ȡ����ʱ������룬���ı��������ANSI���ɽ��
*/

typedef struct FILEData
{
	char* FilePath;
	unsigned FileLine;
	ListData FileData;
}FILEData;

void FILEInit(const char* FilePath, FILEData* file)
{
	CPStrData* temp;
	char* buffer = malloc(1024);
	FILE* pFile = fopen(FilePath, "r");

	if (pFile == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.Init") "�ļ��޷���");

	file->FileLine = 0;
	file->FilePath = malloc(strlen(FilePath) + 1);
	memmove(file->FilePath, FilePath, (strlen(FilePath) + 1));

	FunctionList.Init(&(file->FileData));

	while (fgets(buffer, 1024, pFile) != NULL)
	{
		temp = malloc(sizeof(CPStrData));
		FunctionCPStr.Init(buffer, temp);
		FunctionList.PushBack(temp, &(file->FileData));

		file->FileLine++;
	}

	fclose(pFile);
	free(buffer);
}

void FILEDestory(FILEData* file)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (file->FileData.head== NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.Destory") _ERROR_NULL_);
#endif

	file->FileLine = 0;
	free(file->FilePath);
	file->FilePath = NULL;

	FunctionList.Destory(FunctionCPStr.Destory, file->FileData.head);
	file->FileData.end = file->FileData.head = NULL;
	file->FileData.length = 0;
}

inline CPStrData* FILEAt(const unsigned position, FILEData* file)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (file->FileData.head == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.At") _ERROR_NULL_);
	if (position < 0 || position >= file->FileData.length)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.At") _ERROR_ARGV_(position));
#endif

	return FunctionList.FindNode(position, &(file->FileData))->data;
}

inline void FILESave(FILEData* file)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (file->FileData.head == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.Save") _ERROR_NULL_);
#endif

	FILE* FilePt = fopen(file->FilePath, "w");

	for (ListNode* now = file->FileData.head; now != NULL; now = now->next)
		fprintf(FilePt, "%s", FunctionCPStr.c_str(now->data));

	fclose(FilePt);
}

inline void FILEDeleteLine(const unsigned from, const unsigned to, FILEData* file)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (file->FileData.head == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.DeleteLine") _ERROR_NULL_);
	if (to >= file->FileData.length || from > to || from < 0 || to < 0)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.DeleteLine") _ERROR_ARGV_("from ���� to"));
#endif

	if (from == to)
		FunctionList.DeleteNode(from, FunctionCPStr.Destory, &(file->FileData));
	else
		FunctionList.DeleteList(from, to, FunctionCPStr.Destory, &(file->FileData));
}

inline void FILERepleace(const char* from, const char* to, FILEData* file)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (file->FileData.head == NULL||from==NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.Replace") _ERROR_NULL_);
#endif

	for (ListNode* now = file->FileData.head; now != NULL; now = now->next)
		FunctionCPStr.Relpace(from, to, now->data);
}

inline void FILEPushBack(const char* str, FILEData* file)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (file->FileData.head == NULL||str==NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.PushBack") _ERROR_NULL_);
#endif

	CPStrData* NewElem = malloc(sizeof(CPStrData));

	FunctionCPStr.Init(str, NewElem);
	FunctionCPStr.AppendChar('\n', NewElem);

	FunctionList.PushBack(NewElem, &(file->FileData));
}

inline void FILEInsertLineA(const unsigned position, const char* str, FILEData* file)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (file->FileData.head == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.InsertLineA") _ERROR_NULL_);
	if (position < 0 || position >= file->FileData.length)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.InsertLineA") _ERROR_ARGV_(position));
#endif

	CPStrData* NewElem = malloc(sizeof(CPStrData));

	FunctionCPStr.Init(str, NewElem);
	FunctionCPStr.AppendChar('\n', NewElem);

	FunctionList.InsertA(position, NewElem, &(file->FileData));
}

inline void FILEInsertLineB(const unsigned position, const char* str, FILEData* file)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (file->FileData.head == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.InsertLineB") _ERROR_NULL_);
	if (position < 0 || position >= file->FileData.length)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.InsertLineB") _ERROR_ARGV_(position));
#endif

	CPStrData* NewElem = malloc(sizeof(CPStrData));

	FunctionCPStr.Init(str, NewElem);
	FunctionCPStr.AppendChar('\n', NewElem);

	FunctionList.InsertB(position, NewElem, &(file->FileData));
}

inline void FILEForEach(void(*Op)(CPStrData*), FILEData* file)
{
#ifdef _CPLUS_DEBUG_MODE_
	if (Op == NULL)
		SendErrorMessage(_ERROR_LOCATION_("FunctionFILE.ForEach") _ERROR_NULL_);
#endif

	for (ListNode* now = file->FileData.head; now != NULL; now = now->next)
		Op(now->data);
}

struct
{
	void (*Init)(const char* FilePath, FILEData* file);
	void (*Destory)(FILEData* file);
	CPStrData* (*At)(const unsigned position, FILEData* file);
	void (*Save)(FILEData* file);
	void (*DeleteLine)(const unsigned from, const unsigned to, FILEData* file);
	void (*Repleace)(const char* from, const char* to, FILEData* file);
	void (*PushBack)(const char* str, FILEData* file);
	void (*InsertLineA)(const unsigned position, const char* str, FILEData* file);
	void (*InsertLineB)(const unsigned position, const char* str, FILEData* file);
	void (*ForEach)(void (*Op)(CPStrData*), FILEData* file);
}const static FunctionFILE =
{
&FILEInit,&FILEDestory,&FILEAt,&FILESave,&FILEDeleteLine,
&FILERepleace,&FILEPushBack,&FILEInsertLineA,&FILEInsertLineB,&FILEForEach,
};

/*
printf��װ
PRINTF����ܹ�һ�������10�����������ұ������Ͳ����пո�
(��������пո�Ͱѿո���Ե�����longlong)
�ַ�������Ϊstring
��Ѵ���д�ú��ã���Ҫԭ�������߲������
*/

#define INT "%d"
#define LONG "%ld"
#define LONGINT "%ld"
#define LONGLONG "%lld"
#define LONGLONGINT "%lld"
#define UNSIGNED "%u"
#define UNSIGNEDINT "%u"

#define CHAR "%c"
#define STRING "%s"

#define FLOAT "%f"
#define DOUBLE "%lf"
#define LONGDOUBLE "%Lf"
/*=================����Ϊ���Ͷ���================*/
/*=================����Ϊ�������================*/
#define CPlusPrintf()

#define CPlusPrintfint(pt) printf(INT, pt);
#define CPlusPrintflong(pt) printf(LONG, pt);
#define CPlusPrintflongint(pt) printf(LONG pt);
#define CPlusPrintflonglong(pt) printf(LONG,pt);
#define CPlusPrintflonglongint(pt) printf(LONGLONG,pt);
#define CPlusPrintfunsigned(pt) printf(UNSIGNED, pt);
#define CPlusPrintfunsignedint(pt) printf(UNSIGNED, pt);

#define CPlusPrintfchar(pt) printf(CHAR, pt);
#define CPlusPrintfstring(pt) printf(STRING, pt);

#define CPlusPrintffloat(pt) printf(FLOAT, pt);
#define CPlusPrintfdouble(pt) printf(DOUBLE, pt);
#define CPlusPrintflongdouble  printf(LONGDOUBLE, pt);

#define PRINTF(type1,argv1,type2,argv2,type3,argv3,type4,argv4,type5,argv5,type6,argv6,type7,argv7,type8,argv8,type9,argv9,type10,argv10)\
do{\
CPlusPrintf##type1(argv1) CPlusPrintf##type2(argv2) CPlusPrintf##type3(argv3) CPlusPrintf##type4(argv4) CPlusPrintf##type5(argv5)\
CPlusPrintf##type6(argv6) CPlusPrintf##type7(argv7) CPlusPrintf##type8(argv8) CPlusPrintf##type9(argv9) CPlusPrintf##type10(argv10)\
}while(0);