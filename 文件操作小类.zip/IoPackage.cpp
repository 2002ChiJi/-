#include "IoPackage.h"
using namespace std;
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>

void IoPackage::BuildData()
{
	FileData *file = new FileData;
	FileData *now;
	now = head = file;
	string line;
	getline(IoRead, line);
	file->DataLine = line;
	FileLine++;
	for (; getline(IoRead, line); FileLine++)
	{
		FileData *new_line = new FileData;
		new_line->DataLine = line;
		now->next = new_line;
		now = new_line;
	}
}

void IoPackage::DelData()
{
	FileData *now = head, *del_struct = now;
	for (int num = 1; num != FileLine; num++)
	{
		now = now->next;
		delete del_struct;
		del_struct = now;
	}
}

void IoPackage::SaveWork()
{
	IoWrite.open(FileName);
	FileData *now = head;
	for (int num = 0; num != FileLine; num++)
	{
		IoWrite << now->DataLine << endl;
		now = now->next;
	}
	IoWrite.close();
}
	
IoPackage::IoPackage(const string & FileNameFunction)
{
	head = NULL;
	FileLine=0;
	IoRead.open(FileNameFunction);
	FileName = FileNameFunction;
	BuildData();
}

int IoPackage::LineNum() { return FileLine; }

string& IoPackage::FindFileLine(int ObjLine)
{
	FileData *now;
	now = head;
	for (int num = 1; num != ObjLine; num++)
		now = now->next;
	return now->DataLine;
}

void IoPackage::FileUpate(const string &NewStr)
{
	FileData *new_ = new FileData;
	new_->DataLine = NewStr;
	new_->next = head;
	head = new_;
	FileLine++;
}

void IoPackage::FileUpate(const int &NewInt)
{
	FileData *new_ = new FileData;
	new_->DataLine = NewInt;
	new_->next = head;
	head = new_;
	FileLine++;
}

void IoPackage::FileDelLine(const int  DelLine)
{
	FileData *del=NULL, *del_up=NULL, *now = head;
	for (int num = 1; num != DelLine; num++)
	{
		del_up = now;
		now = now->next;
		del = now;
	}
	del_up->next = del->next;
	delete del;
	FileLine--;
}

void IoPackage::ChangeLineData(const int ObjLine, const string & ChangeData)
{
	FileData *now;
	now = head;
	for (int num = 1; num != ObjLine; num++)
		now = now->next;
	now->DataLine = ChangeData;
}

void IoPackage::ChangeLineData(const int ObjLine, const int  ChangeData)
{
	stringstream buffer;
	buffer << ChangeData;
	FileData *now;
	now = head;
	for (int num = 1; num != ObjLine; num++)
		now = now->next;
	buffer >> now->DataLine;
}

void IoPackage::ChangeName(string & NewName)
{
	IoRead.close();
	SaveWork();
	DelData();
	head = NULL;
	FileLine = 0;
	FileName = NewName;
	IoRead.open(NewName);
	BuildData();
}

IoPackage::~IoPackage()
{
	IoRead.close();
	SaveWork();
	DelData();
}