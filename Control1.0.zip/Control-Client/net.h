﻿#ifndef NET_H
#define NET_H

#include <QByteArray>
#include <QString>
#include <QUdpSocket>
#include <QHostAddress>
#include <QNetworkInterface>

class NetWork :public QObject
{
	Q_OBJECT
private:
	QByteArray Buffer;
	quint16 Port = 10087;
	QHostAddress ReceiverAddr;
	QUdpSocket* Receiver, * Sender;
signals:
	void Connected();
	void DataArrival(QByteArray);
private slots:
	void ReadData()
	{
		Buffer.resize(static_cast<int>(Receiver->bytesAvailable()));
		Receiver->readDatagram(Buffer.data(), Buffer.size());
		QString str = QString::fromUtf8(Buffer);

		if (!QHostAddress(str).isNull())
		{
			ReceiverAddr.setAddress(str);
			disconnect(Receiver, SIGNAL(readyRead()), this, SLOT(ReadData()));

			emit(Connected());
		}
		else emit(DataArrival(Buffer));
	}
public:
	NetWork() :
		ReceiverAddr("1.1.1.1"),
		Receiver(new QUdpSocket),
		Sender(new QUdpSocket)
	{
		Receiver->bind(QHostAddress::Any, Port, QUdpSocket::ShareAddress);
		connect(Receiver, SIGNAL(readyRead()), this, SLOT(ReadData()));
	}
	~NetWork()
	{
		delete Sender;
		delete Receiver;
	}
	void SendData(const QByteArray& datagram)
	{
		Sender->writeDatagram(datagram, ReceiverAddr, Port);
	}
	void SetReceiverAddr(const QHostAddress& Addr)
	{
		ReceiverAddr = Addr;
	}
};
static NetWork* net = nullptr;

#endif // NET_H
