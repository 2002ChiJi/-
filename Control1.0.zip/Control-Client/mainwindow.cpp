﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "operation.h"

inline void SendNoKey(){OperaClient->key=VK_KEY::NoKey;}

void KeepScreenOn(bool on=true)
{
    QtAndroid::runOnAndroidThread([on]{
       QAndroidJniObject activity = QtAndroid::androidActivity();
       if (activity.isValid()) {
         QAndroidJniObject window =
             activity.callObjectMethod("getWindow", "()Landroid/view/Window;");

         if (window.isValid()) {
           const int FLAG_KEEP_SCREEN_ON = 128;
           if (on) {
             window.callMethod<void>("addFlags", "(I)V", FLAG_KEEP_SCREEN_ON);
           } else {
             window.callMethod<void>("clearFlags", "(I)V", FLAG_KEEP_SCREEN_ON);
           }
         }
       }
       QAndroidJniEnvironment env;
       if (env->ExceptionCheck()) env->ExceptionClear();
     });
}/*https://stackoverflow.com/questions/27758499/how-to-keep-the-screen-on-in-qt-for-android*/

QHostAddress GetMyIp()
{
    QList<QHostAddress>list = QNetworkInterface::allAddresses();

    foreach(QHostAddress address, list)
        if (address.toString().contains("192."))
            return address;

    return QHostAddress("0.0.0.0");
}

MainWindow::MainWindow(QWidget* parent) :
    QMainWindow(parent),ui(new Ui::MainWindow),
    timer(new QTimer(this)),direct(nullptr),
    Direction(new QRotationSensor(this)),
    angleSpeed(new QGyroscope(this)),
    angleSpeedRead(nullptr)
{
    ui->setupUi(this);

    net = new NetWork;
    OperaClient = new OperationClient;
    OperaServer = new OperationServer;

    QString Address("IP:");
    Address += GetMyIp().toString() + QString("(未连接)");
    ui->IP->setText(Address);
    connect(net, SIGNAL(Connected()), this, SLOT(ConnectSuccess()));

    ui->Crtl->setDisabled(true);
    ui->Enter->setDisabled(true);
    ui->Shift->setDisabled(true);
    ui->Space->setDisabled(true);
    ui->wheel->setDisabled(true);

    KeepScreenOn();
}

MainWindow::~MainWindow()
{
    delete  net;
    delete  OperaClient;
    delete  OperaServer;
    delete  ui;
}

void MainWindow::ConnectSuccess()
{
    ui->IP->setStyleSheet("font: 20pt \"黑体\";\
                          color: rgb(236, 236, 236);\
            background-color: rgb(0, 170, 148);");
    QString Address("IP:");
    Address += GetMyIp().toString() + QString("(已连接)");
    ui->IP->setText(Address);
    disconnect(net, SIGNAL(Connected()), this, SLOT(ConnectSuccess()));

    ui->Crtl->setDisabled(false);
    ui->Enter->setDisabled(false);
    ui->Shift->setDisabled(false);
    ui->Space->setDisabled(false);
    ui->wheel->setDisabled(false);

    Direction->start();
    connect(Direction,SIGNAL(readingChanged()),this,SLOT(readDirection()));
    angleSpeed->start();
    connect(angleSpeed,SIGNAL(readingChanged()),this,SLOT(readAngle()));

    timer->setInterval(25);
    connect(timer,SIGNAL(timeout()),this,SLOT(SendOperation()));
    timer->start();
}

void MainWindow::on_Crtl_pressed(){OperaClient->key=VK_KEY::Ctrl;}
void MainWindow::on_Enter_pressed(){OperaClient->key=VK_KEY::Enter;}
void MainWindow::on_Shift_pressed(){OperaClient->key=VK_KEY::Shift;}
void MainWindow::on_Space_pressed(){OperaClient->key=VK_KEY::Space;}
void MainWindow::on_wheel_sliderMoved(int position){OperaClient->dial=position;}

void MainWindow::on_Crtl_released(){SendNoKey();}
void MainWindow::on_Enter_released(){SendNoKey();}
void MainWindow::on_Shift_released(){SendNoKey();}
void MainWindow::on_Space_released(){SendNoKey();}
void MainWindow::on_wheel_sliderReleased(){OperaClient->dial=VK_KEY::NoKey;}

void MainWindow::readAngle()
{
    angleSpeedRead=angleSpeed->reading();
    OperaClient->XAngle=angleSpeedRead->x();
    OperaClient->YAngle=angleSpeedRead->y();
    OperaClient->ZAngle=angleSpeedRead->z();
}

void MainWindow::readDirection()
{
    direct=Direction->reading();
    OperaClient->x=static_cast<qint16>(direct->x());
    OperaClient->y=static_cast<qint16>(direct->y());
    OperaClient->z=static_cast<qint16>(direct->z());
}

void MainWindow::SendOperation(){OperaClient->SendOpera();}
