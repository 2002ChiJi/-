﻿#ifndef OPRATION_H
#define OPRATION_H

#include "net.h"
#include <QDataStream>
const quint8 MyNull = 255;
enum VK_KEY { Space = 32, Ctrl = 17, Enter = 13, Shift = 16, NoKey = MyNull };

class OperationClient
{
public:
    int dial;
    quint8 key;
    qint16 x,y,z;
    qreal XAngle,YAngle,ZAngle;
public:
    void SendOpera()
    {
        QByteArray Buffer;
        QDataStream stream(&Buffer,QIODevice::ReadWrite);
        stream.setVersion(QDataStream::Qt_5_12);
        stream<<dial<<key<<x<<y<<z<<XAngle<<YAngle<<ZAngle;
        net->SendData(Buffer);
    }
};
static OperationClient* OperaClient = nullptr;

class OperationServer :public QObject
{
    Q_OBJECT
signals:
    void StateUpdated();
private slots:
    void UpdateState(QByteArray Data)
    {
        QDataStream stream(&Data,QIODevice::ReadWrite);
        stream.setVersion(QDataStream::Qt_5_12);
        stream>>dial>>key>>x>>y>>z>>XAngle>>YAngle>>ZAngle;

        emit StateUpdated();
    }
public:
    int dial;
    quint8 key;
    qint16 x,y,z;
    qreal XAngle,YAngle,ZAngle;
public:
    OperationServer()
    {
        connect(net, SIGNAL(DataArrival(QByteArray)), this, SLOT(UpdateState(QByteArray)));
    }
};
static OperationServer* OperaServer = nullptr;
#endif // OPRATION_H
