﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QTimer>
#include <QGyroscope>
#include <QMainWindow>
#include <QRotationSensor>

#include <QtAndroid>
#include <QAndroidJniEnvironment>
#include <QAndroidJniObject>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow();
private:
    Ui::MainWindow* ui;
    QTimer* timer;
    QRotationReading *direct;
    QRotationSensor *Direction;
    QGyroscope *angleSpeed;
    QGyroscopeReading *angleSpeedRead;
private slots:
    void ConnectSuccess();
    void on_wheel_sliderMoved(int position);
    void on_Enter_pressed();
    void on_Shift_pressed();
    void on_Crtl_pressed();
    void on_Space_pressed();
    void on_Enter_released();
    void on_Shift_released();
    void on_Crtl_released();
    void on_Space_released();
    void on_wheel_sliderReleased();
    void readAngle();
    void readDirection();
    void SendOperation();
};
#endif // MAINWINDOW_H
