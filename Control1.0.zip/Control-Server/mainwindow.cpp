﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "keyboard.h"

QHostAddress GetMyIp()
{
	QList<QHostAddress>list = QNetworkInterface::allAddresses();

	foreach(QHostAddress address, list)
		if (address.toString().contains("192."))
			return address;

	return QHostAddress("0,0,0,0");
}

MainWindow::MainWindow(QWidget* parent) :
	QMainWindow(parent),
	ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	setWindowFlags(Qt::FramelessWindowHint);
	ui->IP->setContextMenuPolicy(Qt::NoContextMenu);

	net = new NetWork;
	OperaClient = new OperationClient;
	OperaServer = new OperationServer;
	msgSender = new KeybdMsgSender(OperaServer);

	connect(OperaServer, SIGNAL(StateUpdated()), msgSender, SLOT(Send()));
    srand(static_cast<unsigned int>(time(nullptr)));
}

MainWindow::~MainWindow()
{
	delete ui;
}

void MainWindow::mousePressEvent(QMouseEvent* e)
{
    if (e->button() == Qt::LeftButton)
		last = e->globalPos();
}

void MainWindow::mouseMoveEvent(QMouseEvent* e)
{
    if (e->buttons() == Qt::LeftButton)
	{
		int dx = e->globalX() - last.x();
		int dy = e->globalY() - last.y();
		last = e->globalPos();
		move(x() + dx, y() + dy);
	}
}
//鼠标按下

void MainWindow::mouseReleaseEvent(QMouseEvent* e)
{
    if (e->button() == Qt::LeftButton)
	{
		int dx = e->globalX() - last.x();
		int dy = e->globalY() - last.y();
		move(x() + dx, y() + dy);
	}
}

void MainWindow::on_link_clicked()
{
	if (!QHostAddress(ui->IP->text()).isNull())
	{
		net->SetReceiverAddr(QHostAddress(ui->IP->text()));

		QString MyIp = GetMyIp().toString();
		net->SendData(QByteArray((MyIp.toStdString().c_str())));
	}
	else
		ui->IP->setText(QString("输入手机端显示的IP地址"));
}

void MainWindow::on_close_clicked()
{
	delete  net;
	delete  msgSender;
	delete  OperaClient;
	delete  OperaServer;

	this->close();
}
