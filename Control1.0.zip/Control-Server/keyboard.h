﻿#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <windows.h>
#include <dinput.h>
#include "operation.h"

static const quint8 VK_KEY[8] = { 87,65,83,68,VK_SPACE,
                                  VK_CONTROL,VK_RETURN,VK_SHIFT };/*WASD*/

class KeybdMsgSender :public QObject
{
    Q_OBJECT
private:
    bool IsClearedWS,IsClearedDA;
    INPUT input[2][4];
    OperationServer* Receiver;
    inline void W()
    {
        IsClearedWS=false;
        SendInput(1, &input[1][2], sizeof(INPUT));
        SendInput(1, &input[0][0], sizeof(INPUT));
    }
    inline void A()
    {
        IsClearedDA=false;
        SendInput(1, &input[1][3], sizeof(INPUT));
        SendInput(1, &input[0][1], sizeof(INPUT));
    }
    inline void S()
    {
        IsClearedWS=false;
        SendInput(1, &input[1][0], sizeof(INPUT));
        SendInput(1, &input[0][2], sizeof(INPUT));
    }
    inline void D()
    {
        IsClearedDA=false;
        SendInput(1, &input[1][1], sizeof(INPUT));
        SendInput(1, &input[0][3], sizeof(INPUT));
    }
    inline void ClearDA()
    {
        if(!IsClearedDA)
        {
            SendInput(1, &input[1][1], sizeof(INPUT));
            SendInput(1, &input[1][3], sizeof(INPUT));
            IsClearedDA=true;
        }
    }
    inline void ClearWS()
    {
        if(!IsClearedWS)
        {
            SendInput(1, &input[1][0], sizeof(INPUT));
            SendInput(1, &input[1][2], sizeof(INPUT));
            IsClearedWS=true;
        }
    }
private slots:
    void Send()
    {
        qint16 x=Receiver->x,y=Receiver->y;
        
        if(abs(x)>15&&abs(x)<30)(x>0)?D():A();
        else ClearDA();
        if(abs(y)>15) (y>0)?W():S();
        else ClearWS();

    }
public:
    KeybdMsgSender(OperationServer* receiver) :IsClearedWS(false),IsClearedDA(false),Receiver(receiver)
    {
        memset(&input,0,sizeof(INPUT));
        input[0][0].ki.wScan=input[1][0].ki.wScan=DIK_W;
        input[0][1].ki.wScan=input[1][1].ki.wScan=DIK_A;
        input[0][2].ki.wScan=input[1][2].ki.wScan=DIK_S;
        input[0][3].ki.wScan=input[1][3].ki.wScan=DIK_D;
        input[0][0].type=input[0][1].type=input[0][2].type=input[0][3].type = INPUT_KEYBOARD;
        input[1][0].type=input[1][1].type=input[1][2].type=input[1][3].type = INPUT_KEYBOARD;
        input[0][0].ki.dwFlags=input[0][1].ki.dwFlags=input[0][2].ki.dwFlags=input[0][3].ki.dwFlags = KEYEVENTF_SCANCODE;
        input[1][0].ki.dwFlags=input[1][1].ki.dwFlags=input[1][2].ki.dwFlags=input[1][3].ki.dwFlags = KEYEVENTF_SCANCODE|KEYEVENTF_KEYUP;
    }
};

static KeybdMsgSender* msgSender = nullptr;
#endif // KEYBOARD_H
