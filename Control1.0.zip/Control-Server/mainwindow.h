﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMouseEvent>

namespace Ui {
	class MainWindow;
}

class MainWindow : public QMainWindow
{
	Q_OBJECT
private slots:
	void mouseMoveEvent(QMouseEvent* e)    override;
	void mousePressEvent(QMouseEvent* e)   override;
	void mouseReleaseEvent(QMouseEvent* e) override;

	void on_link_clicked();

	void on_close_clicked();

public:
	~MainWindow() override;
	explicit MainWindow(QWidget* parent = nullptr);

private:
	QPoint last;
	Ui::MainWindow* ui;
};

#endif // MAINWINDOW_H
