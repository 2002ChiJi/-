#include <thread>
#include <mutex>

/*
监听线程数，
使用方法：
当创建新线程时，需要在新线程内部创建该类的一个实例，并传入1，否则该线程不计入RemainThread中：
创建语句： ThreadMonitor<GetType(执行线程的函数名)>(1);
要获取某个函数所正在执行的线程数，需要这么做：
ThreadMonitor<GetType(某个函数)>(0).GetRemain(); 
//会返回线程数，但是“某个函数”必须在被调用时创建该类的实例，填入的数字必须为0，否则会被记入RemainThread中

利用脱离作用域自动调用析构函数的特性同步还在工作的线程数
利用模板的特性确保每个函数都可以单独有一个监听的类而不至于重复统计
利用多线程的锁确保在修改共享数据：RemainThread 时不会报错
利用静态成员确保共享多个成员： RemainThread和Lock，前者负责统计在工作的线程，后者负责上锁和解锁前者
利用函数宏，好让实例化过程更加友好
*/
template<class MonitorObj>
class ThreadMonitor
{
private:

	bool NewThread;
	static std::mutex Lock;
	static int RemainThread;

public:
	ThreadMonitor(bool NewThread_)
	{
		Lock.lock();

		NewThread = NewThread_;
		if (NewThread)RemainThread++;

		Lock.unlock();
	}
	~ThreadMonitor()
	{
		if (NewThread)
		{
			Lock.lock();
			RemainThread--;
			Lock.unlock();
		}
	}
	int GetRemain() { return RemainThread; }
};
template<typename MonitorObj> std::mutex ThreadMonitor<MonitorObj>::Lock;
template<typename MonitorObj> int ThreadMonitor<MonitorObj>::RemainThread = 0;
#define GetTy(_Ty) decltype(_Ty)