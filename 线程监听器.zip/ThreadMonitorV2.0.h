#include <thread>
#include <mutex>

namespace ThreadMonitor_
{
	/*
	监听线程数，
	使用方法：
	当创建新线程时，需要在新线程内部创建该类的一个实例，并传入1，否则该线程不计入RemainThread中：
	创建语句： ThreadMonitor<GetType(执行线程的函数名)>(1);
	要获取某个函数所正在执行的线程数，需要这么做：
	ThreadMonitor<GetType(某个函数)>(0).GetRemain();
	//会返回线程数，但是“某个函数”必须在被调用时创建该类的实例，填入的数字必须为0，否则会被记入RemainThread中

	***您可以使用ToClass,来将一个函数转换为本质为类的函数对象，
	使得即使原本函数签名相同的函数也不会公用一个ThreadMonitor以至于无法准确地监视线程数量，使用示例：
	ToClass(函数名字，函数名字(参数)
	{
	....函数体....
	});
	通过这一步转换之后，您可以像使用函数一样使用被转换出的函数对象，同时也不能，也没必要使用GetTy宏
	*/
	template<class MonitorObj>
	class ThreadMonitor
	{
		bool NewThread;
		static std::mutex Lock;
		static int RemainThread;

	public:
		ThreadMonitor(bool NewThread_)
		{
			Lock.lock();

			NewThread = NewThread_;
			if (NewThread)RemainThread++;

			Lock.unlock();
		}
		~ThreadMonitor()
		{
			if (NewThread)
			{
				Lock.lock();				RemainThread--;
				Lock.unlock();
			}
		}
		int GetRemain() { return RemainThread; }
	};

	template<typename MonitorObj> std::mutex ThreadMonitor<MonitorObj>::Lock;
	template<typename MonitorObj> int ThreadMonitor<MonitorObj>::RemainThread = 0;

#define GetTy(_Ty) decltype(_Ty)

#define _THREAD_MONITOR_
#define FunToClass(RetTy,Name,Argv,FunBody)\
class _THREAD_MONITOR_##Name\
{\
private:\
	void operator=(_THREAD_MONITOR_##Name);\
public:\
	RetTy operator()Argv FunBody\
}; \
static _THREAD_MONITOR_##Name Name;\

}
